#!/bin/bash

palabra="$1"

cuenta=1

while read input; do
	if [ "$input" == "1" ]; then
		let "cuenta++"
	else
		echo -e "${palabra}\t${cuenta}" >> "vocabulario.txt"
		rm "/tmp/vocabulario/$palabra"
		exit
	fi
done < <(nc -lUk "/tmp/vocabulario/$palabra")
