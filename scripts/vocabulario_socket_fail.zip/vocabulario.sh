#!/bin/bash

archivo="$1"
#~ salida="$2"
ruta="${0%/*}"

#~ if [ -d "$salida" ]; then
	#~ rm -r "$salida"
#~ fi
#~ mkdir "$salida"

if [ -d "/tmp/vocabulario" ]; then
	rm -r "/tmp/vocabulario"
fi
mkdir "/tmp/vocabulario"
mkdir "/tmp/vocabulario/_"

while read line; do
    for word in $line; do
		word="_${word}_"
		echo "$word"
        echo "1" | nc -U -q 1 "/tmp/vocabulario/$word" || $ruta/vocabulario_socket.sh "$word" "$ruta"
    done
done < "$archivo"

for socket in /tmp/vocabulario/*; do
		echo "exec QUIT" | nc -U "$socket"
done
