#!/bin/bash

palabra="$1"
ruta="$2"

$ruta/socket.sh "$palabra" &
