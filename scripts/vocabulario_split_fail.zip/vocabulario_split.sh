#!/bin/bash
#~ sudo mount -t tmpfs -o size=512M tmpfs /tmp/ram/

archivo="$1"
salida="$2"
ruta="${0%/*}"

if [ -f "$salida" ]; then
	rm "$salida"
fi

mkdir "/tmp/vocabulario/_"

parallel -j 0 $ruta/vocabulario_split_main.sh :::: "$archivo"

find /tmp/vocabulario -type f -exec bash -c '$1/vocabulario_split_output.sh "$2" "$3" &' - "$ruta" {} "$salida" \;
