#!/bin/bash

archivo="$1"
salida="$2"

cuenta=$(<"/tmp/vocabulario/_${archivo}_")
rm "$archivo"

palabra="${archivo%_}"
palabra="${palabra##*_}"

echo -e "$palabra\t$cuenta" >> "$salida"
