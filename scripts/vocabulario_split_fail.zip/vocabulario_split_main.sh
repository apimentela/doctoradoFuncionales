#!/bin/bash

entrada="$1"

for word in $entrada; do
	if [ -f "/tmp/vocabulario/_${word}_" ]; then
		cuenta=$(<"/tmp/vocabulario/_${word}_")
		echo "" > "/tmp/vocabulario/_${word}_"
		while [ -z $cuenta ]; do
			cuenta=$(<"/tmp/vocabulario/_${word}_")
		done
	else
		cuenta=0
	fi
	(( cuenta++ ))
	echo $cuenta > "/tmp/vocabulario/_${word}_"
done
